# Housing Price Predictions in Delhi
Used the database in Kaggle (link) for Delhi to make a model using multiple Linear Regression (Ordinary Least Squares method).
Used Numpy, Pandas, Seaborn for graphing, and scikit learn.
Has ~40 Attributes, off which 21 were dropped in preprocessing.
Out of 5000 records, around half had to be dropped because of missing data in all columns.
